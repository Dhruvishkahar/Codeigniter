<?php
// $this->session->set_userdata($sess_array);
// $this->session->unset_userdata($sess_array);

$sess_array = array(

					"reg_id" => $reg->reg_id,
					"reg_fname"=>$reg->reg_fname,
					"reg_lname"=>$reg->reg_lname,
					"reg_email"=>$reg->reg_email,
					"reg_dob"=>$reg->reg_dob
				);
		$this->session->unset_userdata($sess_array);
		$this->session->sess_destroy();
?>



<!-- $newdata = array(
                'user_name'  =>'',
                'user_email' => '',
                'logged_in' => FALSE,
               );

     $this->session->unset_userdata($newdata);
     $this->session->sess_destroy();
 -->




    <!--  $sess_array = array(

					"reg_id" => $reg->reg_id,
					"reg_fname"=>$reg->reg_fname,
					"reg_lname"=>$reg->reg_lname,
					"reg_email"=>$reg->reg_email,
					"reg_password"=>$reg->reg_password,
					"reg_dob"=>$reg->reg_dob
				);
		$this->session->unset_userdata($sess_array);
		$this->session->sess_destroy(); -->
