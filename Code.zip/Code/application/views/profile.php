<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
</head>
<body>
	<table border="2" align="center" cellspacing="10" cellpadding="10" style="background:#d9fdff;">
	
	<tr >
		<tr>
			<th><?php echo $this->session->userdata('reg_fname');?></th>
			<th> <a href="<?php echo base_url()?>welcome/logout">logout</a> </tH>
		</tr>
		
		<th>id</th>
		<tH> fname </tH>
		<th>lname</th>
		<th> email </tH>
		
			
			   </tr>

			   

			   		<tr>
			   			<td>  <?php echo $this->session->userdata('reg_id');?> </td>
			   			<td>  <?php echo $this->session->userdata('reg_fname');?></td>
			   			<td> <?php echo $this->session->userdata('reg_lname');?></td>
			   			<td>  <?php echo $this->session->userdata('reg_email');?> </td>
			   			</tr>
			   		
			   		
			   


			

							</table> 

</body>
</html>