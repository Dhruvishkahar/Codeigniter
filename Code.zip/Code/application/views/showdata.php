<!DOCTYPE html>
<html lang="en">
<head>
  <title>Showdata</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2 align="center">Showdata</h2>
            
  <table class="table">
    <thead>
      <tr>
      
      	<th>Registration_Id</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
        <th>Password</th>
        <th>Date Of Birth</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <?php
    	foreach ($all_data as $key => $value) {?>
    	<tbody>
    		<tr>
    	 <td><?php echo $value->reg_id;?></td>
          <td><?php echo $value->reg_fname;?></td>	
    			<td><?php echo $value->reg_lname;?></td>	
    			<td><?php echo $value->reg_email;?></td>	
    			<td><?php echo $value->reg_password;?></td>
    			<td><a href="<?php echo base_url()?>welcome/delete/<?php echo $value->reg_id;?>">Delete</a></td>
    			<td><a href="<?php echo base_url()?>welcome/update/<?php echo $value->reg_id;?>">Update</a></td>
    		</tr>
       
    		
    	</tbody>
    <?php	}

    ?>
    
  </table>
  <!--  <tr>
          <td><a href="<?php echo base_url()?>welcome/delete_all/<?php echo $value->reg_id;?>">Delete all</a></td>
        </tr> -->
</div>

</body>
</html>
