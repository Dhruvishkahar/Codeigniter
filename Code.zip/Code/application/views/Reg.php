<!DOCTYPE html>
<html>
<head>
	<title>Reg</title>
</head>
<body>
	<form method="POST" action="<?php echo base_url('Welcome/add_data')?>">
		<label>Emaik</label>
		<input type="'email" name="email" placeholder="email"><br>
		<label>Password</label>
		<input type="password" name="password" placeholder="*********"><br>
		<input type="submit" name="submit" value="submit">
	</form>
	<table>
		<thead>
			<tr>
				<td>Email</td>
				<td>password</td>
			</tr>
		</thead>
		<?php
		foreach ($data as $key => $value) {?>
			<tbody>
			<tr>
				<td><?php echo $value->user_email;?></td>
				<td><?php echo $value->user_password;?></td>
			</tr>
		</tbody>
		<?php }

		?>
		
	</table>
</body>
</html>