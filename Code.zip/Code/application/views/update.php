<h2 align="center">Update Data</h2>
<?php
	
	foreach ($update_data as $key => $value) {?>

	<table class="table" border="2" cellpadding="4" cellspacing="4" align="center">
	<form method="POST" action="<?php echo base_url()?>welcome/updatedata" enctype="multipart/form-data">
	<tr>
		<td>Registration_Id</td>
		<td><input type="text" name="reg_id" readonly value="<?php echo $value->reg_id;?>"></td></tr>
		<tr>
		<td>FirstName</td>
		<td><input type="text" name="fname"   value="<?php echo $value->reg_fname;?>"></td>
	</tr>
	<tr>
		<td>LastName</td>
		<td><input type="text" name="lname" value="<?php echo $value->reg_lname;?>"></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><input type="email" name="email" value="<?php echo $value->reg_email;?>"></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><input type="text" name="password" value="<?php echo $value->reg_password;?>"></td>
	</tr>
	
	
	<tr>
		
		<td colspan="2" align="center"><input type="submit" name="submit" value="update"></td>
	</tr>
	</form>
</table>


<?php }?>
 