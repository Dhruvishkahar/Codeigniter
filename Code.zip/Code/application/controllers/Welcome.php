<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->Model('Model');
	}
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function reg()
	{
		$show['data']=$this->Model->select_all("user");
		$this->load->view('reg',$show);
	}
	public function add_data()
	{
		//echo "oke";
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$data = array("user_email"=>$email,"user_password"=>$password);
		$insert = $this->Model->insert("user",$data);
		if($insert)
		{
			redirect('Welcome/reg');
		}
		else
		{
			echo "Error";
		}
	}
	public function showdata()
	{
		$data['all_data'] = $this->Model->select_all("reg");
		$this->load->view('showdata',$data);

	}
	public function delete($id)
	{
		$where = array("reg_id"=>$id);
		$delete = $this->Model->delete("reg",$where);

		if($delete)
		{
			redirect('welcome/showdata');
		}
		else
		{
			echo "Error";
		}

	}
	public function update($id)
	{
		//echo "$id";

		$where = array("reg_id"=>$id);
		//print_r($where);
		$data['update_data'] = $this->Model->select_where("reg",$where);
		//print_r($data['update_data']);


		$this->load->view('update',$data);

	}
	public function updatedata()
	{
		$reg_id = $this->input->post('reg_id');
		$where = array("reg_id"=>$reg_id);
		$data['reg_fname'] =$this->input->post('fname');
		$data['reg_lname'] =$this->input->post('lname');
		$data['reg_email'] =$this->input->post('email');
		$data['reg_password'] =md5($this->input->post('password'));
		// $data['reg_dob'] =$this->input->post('dob');

		// $config['upload_path']          = './uploads/';
  //       $config['allowed_types']        = 'gif|jpg|png';
  //       // $config['max_size']             = 100;
  //       // $config['max_width']            = 1024;
  //       // $config['max_height']           = 768;
  //       $this->load->library('upload', $config);
 	// 	$this->upload->do_upload('image');
 	// 	$upload_data = $this->upload->data();
 	// 	$data['reg_image'] = $upload_data['file_name'];



		$update = $this->Model->update("reg",$data,$where);

		if($update)
		{

			redirect('welcome/showdata');
		}
		
		else
		{
			echo "Error";
		}

	}
	public function login()
	{
		$this->load->view('login');
	}
	 public function auth()
	{



		$data['reg_email'] = $this->input->post('email');
		$data ['reg_password'] = md5($this->input->post('password'));
		//print_r($data);
		$login = $this->Model->select_where("reg",$data);
		//print_r($login);
		
		if(count($login) == 1 )
		{
			$this->load->library('session');
			$sess_array = array();//data member
			foreach ($login as $reg) {
				$sess_array = array(

					"reg_id" => $reg->reg_id,
					"reg_fname"=>$reg->reg_fname,
					"reg_lname"=>$reg->reg_lname,
					"reg_email"=>$reg->reg_email,
					"reg_password"=>$reg->reg_password,
					
				);

				$this->session->set_userdata($sess_array);
				
			}
			
			redirect('welcome/showdata');

		}
		else
		{

			redirect('welcome/login');
		}

	}
	public function profile()
	{
		// if (empty($this->session->userdata('reg_id'))) {
		// 	redirect('welcome/login');
		// }
		// else
		// {
		// 	$this->load->view('welcome/login');
		// }
		$this->load->view('profile');
	}
	public function logout()
	{
		$this->load->library('session');
		$this->session->sess_destroy();

    	redirect('welcome/login');
	}
}
